QIUMC.plugin({
  id: 'qiumc-demo-pack-main',
  name: '声明式包内插件',
  version: '1.0.0',
  description: 'plugin.json 的 main 指定的代码',
  capabilities: ['command'],
}, function (P) {
  P.addCommand('qpack', { description: '声明式插件包自检', fn: function (ctx) {
    ctx.say('声明式插件包已加载，方块数：' + QIUMC.Plugins.list().filter(function (r) { return r.blocks; }).length);
  } });
});
